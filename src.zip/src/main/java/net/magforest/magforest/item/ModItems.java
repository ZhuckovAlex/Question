package net.magforest.magforest.item;

import net.magforest.magforest.block.ModBlocks;
import net.magforest.magforest.magforest;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.*;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems
{

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, magforest.MOD_ID);

    public static final RegistryObject<Item> CIAN_SIGN = ITEMS.register("cian_sign",
            () -> new SignItem(new Item.Properties().maxStackSize(16).group(ModItemGroup.THAUM_BLOCKS),
                    ModBlocks.CIAN_SIGN.get(), ModBlocks.CIAN_WALL_SIGN.get()));
    public static final RegistryObject<Item> DARK_BIRCH_SIGN = ITEMS.register("dark_birch_sign",
            () -> new SignItem(new Item.Properties().maxStackSize(16).group(ModItemGroup.THAUM_BLOCKS),
                    ModBlocks.DARK_BIRCH_SIGN.get(), ModBlocks.DARK_BIRCH_WALL_SIGN.get()));

    public static final RegistryObject<Item> KARAMBOLA = ITEMS.register("karambola",
            () -> new BlockItem(ModBlocks.KARAMBOLA.get(), new Item.Properties()
                    .group(ModItemGroup.THAUM_ITEMS)));

    public static final RegistryObject<Item> CIAN_LEAVES = ITEMS.register("cian_leaves",
            () -> new BlockItem(ModBlocks.CIAN_LEAVES.get(), new Item.Properties()
                    .group(ModItemGroup.THAUM_BLOCKS)));
    public static final RegistryObject<Item> CIAN_SAPLING = ITEMS.register("cian_sapling",
            () -> new BlockItem(ModBlocks.CIAN_SAPLING.get(), new Item.Properties()
                    .group(ModItemGroup.THAUM_BLOCKS)));
    public static final RegistryObject<Item> DARK_BIRCH_LEAVES = ITEMS.register("dark_birch_leaves",
            () -> new BlockItem(ModBlocks.DARK_BIRCH_LEAVES.get(), new Item.Properties()
                    .group(ModItemGroup.THAUM_BLOCKS)));
    public static final RegistryObject<Item> DARK_BIRCH_SAPLING = ITEMS.register("dark_birch_sapling",
            () -> new BlockItem(ModBlocks.DARK_BIRCH_SAPLING.get(), new Item.Properties()
                    .group(ModItemGroup.THAUM_BLOCKS)));
    public static final RegistryObject<Item> CRIMSON_SAPLING = ITEMS.register("crimson_sapling",
            () -> new BlockItem(ModBlocks.CRIMSON_SAPLING.get(), new Item.Properties()
                    .group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> WARPED_SAPLING = ITEMS.register("warped_sapling",
            () -> new BlockItem(ModBlocks.WARPED_SAPLING.get(), new Item.Properties()
                    .group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> WARPED_WART = ITEMS.register("warped_wart",
            () -> new BlockItem(ModBlocks.WARPED_WART.get(), new Item.Properties()
                    .group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> HYACINTH = ITEMS.register("hyacinth",
            () -> new BlockItem(ModBlocks.HYACINTH.get(), new Item.Properties()
                    .group(ModItemGroup.THAUM_BLOCKS)));
    public static final RegistryObject<Item> RUBY = ITEMS.register("ruby",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_KNIFE = ITEMS.register("ruby_knife",
            () -> new SwordItem(ModItemTier.RUBY, 6,-2,  new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_PICKAXE = ITEMS.register("ruby_pickaxe",
            () -> new PickaxeItem(ModItemTier.RUBY, 4,-2,  new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_AXE = ITEMS.register("ruby_axe",
            () -> new AxeItem(ModItemTier.RUBY, 8,-3,  new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_SHOVEL = ITEMS.register("ruby_shovel",
            () -> new ShovelItem(ModItemTier.RUBY, 4.5f,-2,  new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_HOE = ITEMS.register("ruby_hoe",
            () -> new HoeItem(ModItemTier.RUBY, 0,-2,  new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_BOOTS = ITEMS.register("ruby_boots",
            () -> new ArmorItem(ModArmorMaterial.RUBY, EquipmentSlotType.FEET,
                    new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_LEGGINGS = ITEMS.register("ruby_leggings",
            () -> new ArmorItem(ModArmorMaterial.RUBY, EquipmentSlotType.LEGS,
                    new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_CHESTPLATE = ITEMS.register("ruby_chestplate",
            () -> new ArmorItem(ModArmorMaterial.RUBY, EquipmentSlotType.CHEST,
                    new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_HELMET = ITEMS.register("ruby_helmet",
            () -> new ArmorItem(ModArmorMaterial.RUBY, EquipmentSlotType.HEAD,
                    new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_HORSE_ARMOR = ITEMS.register("ruby_horse_armor",
            () -> new HorseArmorItem(15, "ruby",
                    new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBYNITE_INGOT = ITEMS.register("rubynite_ingot",
            () -> new Item(new Item.Properties().isImmuneToFire().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBYNITE_AXE = ITEMS.register("rubynite_axe",
            () -> new AxeItem(ModItemTier.RUBYNITE,10,-2,new Item.Properties().isImmuneToFire().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBYNITE_SWORD = ITEMS.register("rubynite_sword",
            () -> new SwordItem(ModItemTier.RUBYNITE,8,-1,new Item.Properties().isImmuneToFire().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBYNITE_PICKAXE = ITEMS.register("rubynite_pickaxe",
            () -> new PickaxeItem(ModItemTier.RUBYNITE,6,-1,new Item.Properties().isImmuneToFire().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBYNITE_SHOVEL = ITEMS.register("rubynite_shovel",
            () -> new ShovelItem(ModItemTier.RUBYNITE,6.5f,-1,new Item.Properties().isImmuneToFire().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBYNITE_HOE = ITEMS.register("rubynite_hoe",
            () -> new HoeItem(ModItemTier.RUBYNITE,1,-1,new Item.Properties().isImmuneToFire().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBYNITE_BOOTS = ITEMS.register("rubynite_boots",
            () -> new ArmorItem(ModArmorMaterial.RUBYNITE, EquipmentSlotType.FEET,
                    new Item.Properties().isImmuneToFire().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBYNITE_LEGGINGS = ITEMS.register("rubynite_leggings",
            () -> new ArmorItem(ModArmorMaterial.RUBYNITE, EquipmentSlotType.LEGS,
                    new Item.Properties().isImmuneToFire().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBYNITE_CHESTPLATE = ITEMS.register("rubynite_chestplate",
            () -> new ArmorItem(ModArmorMaterial.RUBYNITE, EquipmentSlotType.CHEST,
                    new Item.Properties().isImmuneToFire().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBYNITE_HELMET = ITEMS.register("rubynite_helmet",
            () -> new ArmorItem(ModArmorMaterial.RUBYNITE, EquipmentSlotType.HEAD,
                    new Item.Properties().isImmuneToFire().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_POWDER = ITEMS.register("ruby_powder",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> AER_POWDER = ITEMS.register("aer_powder",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> AQUA_POWDER = ITEMS.register("aqua_powder",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> ETHER_POWDER = ITEMS.register("ether_powder",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> FLAME_POWDER = ITEMS.register("flame_powder",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> TERRA_POWDER = ITEMS.register("terra_powder",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> AER_MIX = ITEMS.register("aer_mix",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> AQUA_MIX = ITEMS.register("aqua_mix",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> ETHER_MIX = ITEMS.register("ether_mix",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> FLAME_MIX = ITEMS.register("flame_mix",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> TERRA_MIX = ITEMS.register("terra_mix",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> DARK_BIRCH_CORE = ITEMS.register("dark_birch_core",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> GOLDEN_CAP = ITEMS.register("golden_cap",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> IRON_CAP = ITEMS.register("iron_cap",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> RUBY_CAP = ITEMS.register("ruby_cap",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> DARK_BIRCH_WAND_FRAMED_BY_GOLD = ITEMS.register("dark_birch_wand_framed_by_gold",
            () -> new Item(new Item.Properties().maxStackSize(1).group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> DARK_BIRCH_WAND_FRAMED_BY_IRON = ITEMS.register("dark_birch_wand_framed_by_iron",
            () -> new Item(new Item.Properties().maxStackSize(1).group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> DARK_BIRCH_WAND_FRAMED_BY_RUBY = ITEMS.register("dark_birch_wand_framed_by_ruby",
            () -> new Item(new Item.Properties().maxStackSize(1).group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> PESTLE = ITEMS.register("pestle",
            () -> new Item(new Item.Properties().group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> MORTAR_AND_PESTLE = ITEMS.register("mortar_and_pestle",
            () -> new DamageItem(new Item.Properties().maxStackSize(1).maxDamage(64).group(ModItemGroup.THAUM_ITEMS)));
    public static final RegistryObject<Item> MAGICA = ITEMS.register("magica",
            () -> new Item(new Item.Properties().maxStackSize(1).group(ModItemGroup.THAUM_ITEMS)));


    public static final RegistryObject<Item> KARAMBOLA_FRUIT = ITEMS.register("karambola_fruit",
            () -> new Item (new Item.Properties().food(new Food.Builder().hunger(6).saturation(0.4f).build())
                    .group(ModItemGroup.THAUM_ITEMS)));
    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }

}
