package net.magforest.magforest.tileentity;

import net.magforest.magforest.block.ModBlocks;
import net.magforest.magforest.item.ModItems;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.Direction;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class LightMachineTile extends TileEntity {

    private final ItemStackHandler itemHandler = createHandler();
    private final LazyOptional<IItemHandler> handler = LazyOptional.of(()-> itemHandler);

    public LightMachineTile(TileEntityType<?> tileEntityTypeIn) {
        super(tileEntityTypeIn);
    }
    public LightMachineTile(){
        this(ModTileEntities.RUBY_LIGHTING_TILE.get());
    }
    @Override
    public void read(BlockState state, CompoundNBT nbt) {
        itemHandler.deserializeNBT(nbt.getCompound("Inv"));
        super.read(state, nbt);
    }

    @Override
    public CompoundNBT write(CompoundNBT compound) {
        compound.put("Inv", itemHandler.serializeNBT());
        return super.write(compound);
    }
    private ItemStackHandler createHandler(){
        return new ItemStackHandler(2){
            @Override
            protected void onContentsChanged(int slot) {
                markDirty();
            }

            @Override
            public boolean isItemValid(int slot, @Nonnull ItemStack stack) {

                switch (slot){
                    case 0: return stack.getItem() == Items.WARPED_FUNGUS||
                    stack.getItem() == Items.CRIMSON_FUNGUS||
                    stack.getItem() == ModItems.RUBYNITE_INGOT.get();
                    case 1: return stack.getItem() == ModItems.CIAN_SAPLING.get()||
                    stack.getItem() == ModItems.WARPED_SAPLING.get()||
                    stack.getItem() == ModItems.CRIMSON_SAPLING.get()||
                    stack.getItem() == ModItems.RUBYNITE_AXE.get()||
                    stack.getItem() == ModItems.RUBYNITE_PICKAXE.get()||
                    stack.getItem() == ModItems.RUBYNITE_SWORD.get()||
                    stack.getItem() == ModItems.RUBYNITE_HOE.get()||
                    stack.getItem() == ModItems.RUBYNITE_SHOVEL.get()||
                    stack.getItem() == ModItems.RUBY_HOE.get()||
                    stack.getItem() == ModItems.RUBY_SHOVEL.get()||
                    stack.getItem() == ModItems.RUBY_AXE.get()||
                    stack.getItem() == ModItems.RUBY_KNIFE.get()||
                    stack.getItem() == ModItems.RUBY_PICKAXE.get()||
                    stack.getItem() == ModItems.RUBYNITE_CHESTPLATE.get()||
                    stack.getItem() == ModItems.RUBYNITE_BOOTS.get()||
                    stack.getItem() == ModItems.RUBYNITE_LEGGINGS.get()||
                    stack.getItem() == ModItems.RUBYNITE_HELMET.get()||
                    stack.getItem() == ModItems.RUBY_CHESTPLATE.get()||
                    stack.getItem() == ModItems.RUBY_BOOTS.get()||
                    stack.getItem() == ModItems.RUBY_LEGGINGS.get()||
                    stack.getItem() == ModItems.RUBY_HELMET.get();
                    default:
                        return false;
                }
            }
            @Override
            public int getSlotLimit(int slot) {
                return 1;
            }

            @Nonnull
            @Override
            public ItemStack insertItem(int slot, @Nonnull ItemStack stack, boolean simulate) {
                if (!isItemValid(slot, stack)){
                    return stack;
                }

                return super.insertItem(slot, stack, simulate);
            }
        };
    }


    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        if (cap == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY){
            return handler.cast();
        }

        return super.getCapability(cap, side);
    }
    public void lightningHasStruck(){
        boolean hasWarpedInFirstSlot = this.itemHandler.getStackInSlot(0).getCount() > 0
                && this.itemHandler.getStackInSlot(0).getItem() == Items.WARPED_FUNGUS;
        boolean hasCrimsonInFirstSlot = this.itemHandler.getStackInSlot(0).getCount() > 0
                && this.itemHandler.getStackInSlot(0).getItem() == Items.CRIMSON_FUNGUS;
        boolean hasReagentInSecondSlot = this.itemHandler.getStackInSlot(1).getCount() > 0
                && this.itemHandler.getStackInSlot(1).getItem() == ModItems.CIAN_SAPLING.get();
        boolean RubyAxe = this.itemHandler.getStackInSlot(1).getCount() > 0
                && this.itemHandler.getStackInSlot(1).getItem() == ModItems.RUBY_AXE.get();
        boolean RubyHoe = this.itemHandler.getStackInSlot(1).getCount() > 0
                && this.itemHandler.getStackInSlot(1).getItem() == ModItems.RUBY_HOE.get();
        boolean RubyShovel = this.itemHandler.getStackInSlot(1).getCount() > 0
                && this.itemHandler.getStackInSlot(1).getItem() == ModItems.RUBY_SHOVEL.get();
        boolean RubyKnife = this.itemHandler.getStackInSlot(1).getCount() > 0
                && this.itemHandler.getStackInSlot(1).getItem() == ModItems.RUBY_KNIFE.get();
        boolean RubyPickaxe = this.itemHandler.getStackInSlot(1).getCount() > 0
                && this.itemHandler.getStackInSlot(1).getItem() == ModItems.RUBY_PICKAXE.get();
        boolean Rubinite = this.itemHandler.getStackInSlot(0).getCount() > 0
                && this.itemHandler.getStackInSlot(0).getItem() == ModItems.RUBYNITE_INGOT.get();
        boolean RubyniteBoots = this.itemHandler.getStackInSlot(0).getCount() > 0
                && this.itemHandler.getStackInSlot(0).getItem() == ModItems.RUBYNITE_BOOTS.get();
        boolean RubyniteChestplate= this.itemHandler.getStackInSlot(0).getCount() > 0
                && this.itemHandler.getStackInSlot(0).getItem() == ModItems.RUBYNITE_CHESTPLATE.get();
        boolean RubyniteHelmet = this.itemHandler.getStackInSlot(0).getCount() > 0
                && this.itemHandler.getStackInSlot(0).getItem() == ModItems.RUBYNITE_HELMET.get();
        boolean RubiniteLeggings = this.itemHandler.getStackInSlot(0).getCount() > 0
                && this.itemHandler.getStackInSlot(0).getItem() == ModItems.RUBYNITE_LEGGINGS.get();
        boolean RubyBoots = this.itemHandler.getStackInSlot(1).getCount() > 0
                && this.itemHandler.getStackInSlot(1).getItem() == ModItems.RUBY_BOOTS.get();
        boolean RubyChestplate= this.itemHandler.getStackInSlot(1).getCount() > 0
                && this.itemHandler.getStackInSlot(1).getItem() == ModItems.RUBY_CHESTPLATE.get();
        boolean RubyHelmet = this.itemHandler.getStackInSlot(1).getCount() > 0
                && this.itemHandler.getStackInSlot(1).getItem() == ModItems.RUBY_HELMET.get();
        boolean RubyLeggings = this.itemHandler.getStackInSlot(1).getCount() > 0
                && this.itemHandler.getStackInSlot(1).getItem() == ModItems.RUBY_LEGGINGS.get();

        if (hasWarpedInFirstSlot && hasReagentInSecondSlot) {
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.WARPED_SAPLING.get()), false);
        }
        if (hasCrimsonInFirstSlot && hasReagentInSecondSlot){
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.CRIMSON_SAPLING.get()), false);
        }
        if (Rubinite && RubyAxe){
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.RUBYNITE_AXE.get()), false);
        }
        if (Rubinite && RubyPickaxe){
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.RUBYNITE_PICKAXE.get()), false);
        }
        if (Rubinite && RubyKnife){
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.RUBYNITE_SWORD.get()), false);
        }
        if (Rubinite && RubyHoe){
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.RUBYNITE_HOE.get()), false);
        }
        if (Rubinite && RubyShovel){
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.RUBYNITE_SHOVEL.get()), false);
        }
        if (Rubinite && RubyLeggings){
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.RUBYNITE_LEGGINGS.get()), false);
        }
        if (Rubinite && RubyHelmet){
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.RUBYNITE_HELMET.get()), false);
        }
        if (Rubinite && RubyChestplate){
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.RUBYNITE_CHESTPLATE.get()), false);
        }
        if (Rubinite && RubyBoots){
            this.itemHandler.getStackInSlot(0).shrink(1);
            this.itemHandler.getStackInSlot(1).shrink(1);

            this.itemHandler.insertItem(1, new ItemStack(ModItems.RUBYNITE_BOOTS.get()), false);
        }
    }
}
