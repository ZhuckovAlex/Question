package net.magforest.magforest.world.gen;

import net.minecraft.block.Block;
import net.minecraftforge.common.util.Lazy;
import net.magforest.magforest.block.ModBlocks;

public enum OreType {

    RUBY(Lazy.of(ModBlocks.RUBY_ORE), 5, 20, 45, 1),
    CRISTAL_ETHER(Lazy.of(ModBlocks.ETHER_CRISTAL_ORE), 7, 5, 90, 3),
    CRISTAL_AER(Lazy.of(ModBlocks.AER_CRISTAL_ORE), 7, 5, 90, 3),
    CRISTAL_TERRA(Lazy.of(ModBlocks.TERRA_CRISTAL_ORE), 7, 5, 90, 3),
    CRISTAL_AQUA(Lazy.of(ModBlocks.AQUA_CRISTAL_ORE), 7, 5, 90, 3),
    CRISTAL_FLAME(Lazy.of(ModBlocks.FLAME_CRISTAL_ORE), 7, 5, 90, 3);

    private final Lazy<Block> block;
    private final int maxVeinSize;
    private final int minHeight;
    private final int maxHeight;
    private final int veinsPerChunk;


    OreType(Lazy<Block> block, int maxVeinSize, int minHeight, int maxHeight, int veinsPerChunk) {
        this.block = block;
        this.maxVeinSize = maxVeinSize;
        this.minHeight = minHeight;
        this.maxHeight = maxHeight;
        this.veinsPerChunk = veinsPerChunk;
    }
    public int getVeinsPerChunk() {
        return veinsPerChunk;
    }

    public Lazy<Block> getBlock() {
        return block;
    }

    public int getMaxVeinSize() {
        return maxVeinSize;
    }

    public int getMinHeight() {
        return minHeight;
    }

    public int getMaxHeight() {
        return maxHeight;
    }

    public static OreType get(Block block) {
        for (OreType ore : values()) {
            if(block == ore.block) {
                return ore;
            }
        }
        return null;
    }
}
